# TouchLib
In order to integrate the touch driver, let the touch interface be unified. (The following chips are currently supported. CST328, CST816, CST820, GT911, FT3267, FT5x06)
